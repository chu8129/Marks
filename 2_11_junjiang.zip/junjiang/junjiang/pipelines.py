# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import pymongo
from items import *
import time
class JunjiangPipeline(object):
    def __init__(self):
        clinet = pymongo.MongoClient("localhost", 27017)
        db = clinet["junjiang"]
        self.listItem = db["listItem_"+time.strftime("%Y%m%d%H%M%S",time.localtime())]
##        self.novelItem = db["novelItem_"+time.strftime("%Y%m%d%H%M%S",time.localtime())]
        self.novelItem = db["novelItem"]
    def process_item(self, item, spider):
##        print item
        # pass
        # print '*',
        if item and (isinstance(item, rankListItem)):
            try:
                self.listItem.save(dict(item))
                # pass
            except Exception:
                pass
        elif item and (isinstance(item, novelItem)):
            try:
                self.novelItem.save(dict(item))
                # pass
            except Exception:
                pass
