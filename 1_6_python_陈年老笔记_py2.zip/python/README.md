# python-
纪录自己遇到的坑<br>
```Python
from multiprocess import Process<br>
proxy_thread=Process(target=proxt,args=(4,))#tuple 加上，消除歧义<br>
```

