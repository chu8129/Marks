#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:18:13

import urllib2
import urllib
import time
import hashlib
import random
import os
import redis
import sys
import json
import requests
from SSDB import SSDB
from logger import init_logger
from get_headers import get_headers
from config import base_url

logger = init_logger("request web")

def request(param):
    host,port,db,set_name,headers = param
    red = SSDB(host,port)
    logger.info("thread n start...")
    from gevent import monkey; monkey.patch_all()
    import gevent
    while 1:
        logger.debug("while for loop")
        try:
            datas = red.request("qpop_back",[set_name,2]) 
            logger.debug("urls:%s"%datas)
            if len(datas.data) == 0:
                sys.stdout.write("list:%s empty!!"%set_name)
                sys.stdout.flush()
                break
    
            gevent.joinall([gevent.spawn(get_one_page,[base_url,data,headers,red,set_name]) for data in datas.data])

        except Exception as e:
            logger.error(str(e), exc_info=True)
        #break


def get_one_page(param):
    url,data,headers,red,set_name = param
    try:
        import gevent
        with gevent.Timeout(10, True) as timeout:
            data = eval(data)
            data = urllib.urlencode(data)
            headers  = random.choice(headers)
            logger.debug("url:%s,data:%s,headers:%s"%(url,data, headers))
            #req = urllib2.Request(url=url, data=data, headers=headers)
            #res = urllib2.urlopen(req)
            #web = res.read()

            res = requests.post(url = url, data = data, headers = headers, proxies=dict(http='socks5://:@172.16.1.252:8964'))
            web = res.content

            info = red.request("hset",["h_"+set_name,str(data),web])
            logger.debug("save url:%s,info:%s"%(url,str(info)))

        #logger.info("url: %s Done"%(url))
    except Exception as e:
        logger.error(str(e), exc_info=True)
        red.request("qpush_font",[set_name,url])
