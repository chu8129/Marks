#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:37:50

data_path = "./data"
infodict_file = "infodict"

base_url = "http://bang.bluemc.cn/billBoard/getBillBoadList.do"

redis_host = "localhost"
redis_port = 9404
redis_db = 0
redis_db_setname = "bluemc_data"
