#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Last Modified : Wed Jun 19 16:54:12 2019

__author__ = "qiuwen(mail:chu8129@gmail.com) @ 2019-06-19 16:16:42"

import sys
sys.path.append("./")

import logging
logger = logging.getLogger("root")


import itchat
from itchat.content import *
import time
import re
import os

msg_information = {}
# 针对表情包的内容
face_bug = None


@itchat.msg_register([TEXT, PICTURE, FRIENDS, CARD, MAP, SHARING, RECORDING, ATTACHMENT, VIDEO], isFriendChat=True, isMpChat=True)
def handle_receive_msg(msg):
    print(msg)
    global face_bug
    msg_time_rec = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    msg_from = (itchat.search_friends(userName=msg.get('FromUserName', "")) or {}).get('NickName', "") if msg else ""
    msg_time = msg['CreateTime']
    msg_id = msg['MsgId']
    msg_content = None
    msg_share_url = None

    if msg['Type'] == 'Text' or msg['Type'] == 'Friends':
        msg_content = msg['Text']
        print(msg_content)

    elif msg['Type'] == 'Attachment' or msg['Type'] == 'Video' \
        or msg['Type'] == 'Picture'\
            or msg['Type'] == 'Recording':
        msg_content = msg['FileName']
        msg['Text'](str(msg_content))

    elif msg['Type'] == 'Card':
        msg_content = msg['RecommendInfo']['NickName'] + '的名片'
        if msg['RecommendInfo']['Sex'] == 1:
            msg_content += '性别为男'
        else:
            msg_content += '性别为女'

        print(msg_content)

    elif msg['Type'] == 'Map':
        x, y, location = re.search(
            "<location x=\"(.*?)\" y=\"(.*?)\".*label=\"(.*?)\".*", msg['OriContent']).group(1, 2, 3)
        if location is None:
            # 内容为详细地址
            msg_content = r'纬度->' + x.__str__() + "经度->" + y.__str__()
        else:
            msg_content = r"" + location

    elif msg['Type'] == 'Sharing':
        msg_content = msg['Text']
        msg_share_url = msg['Url']
        print(msg_share_url)

    else:
        print(msg)
    face_bug = msg_content

    msg_information.update(
        {
            msg_id: {
                "msg_from": msg_from, "msg_time": msg_time, "msg_time_rec": msg_time_rec,
                "msg_type": msg['Type'],
                "msg_content": msg_content, "msg_share_url": msg_share_url
            }
        }
)


@itchat.msg_register(NOTE, isFriendChat=True, isGroupChat=True, isMpChat=True)
def information(msg):
    if '撤回了一条消息' in msg['Content']:
        old_msg_id = re.search("\<msgid\>(.*?)\<\/msgid\>", msg['Content']).group(1)
        old_msg = msg_information.get(old_msg_id) or {}
        print(old_msg)

        if len(old_msg_id)<11:
            itchat.send_file(face_bug, toUserName='filehelper')
        else:
            msg_body = "【"\
                       + old_msg.get('msg_from', "") + "撤回了】\n"\
                       + old_msg.get("msg_type", "") + "消息:" + "\n"\
                       + old_msg.get("msg_time_rec", "") + "\n"\
                       + r"" + old_msg.get("msg_content", "")

        if old_msg.get('msg_type') == "Sharing":
            msg_body += "\n就是这个链接>" + old_msg.get('msg_share_url', "")

        itchat.send_msg(msg_body, toUserName="filehelper")

        if old_msg.get("msg_type") == "Picture"\
                or old_msg.get("msg_type") == "Recording"\
                or old_msg.get("msg_type") == "Video"\
                or old_msg.get("msg_type") == "Attachment":
            file = "@fil@%s" % (old_msg['msg_content'])
            itchat.send(msg=file, toUserName='filehelper')
            os.remove(old_msg['msg_content'])
        else:
            print(old_msg)

        msg_information.pop(old_msg_id)


itchat.auto_login(hotReload=True)
itchat.run()
