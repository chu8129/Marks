#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:38:07


import logging
import os


def init_logger(name):
    filename = "log.text"
    foldername = "log2"
    local_path = os.getcwd()
    log_folder = os.path.join(local_path, foldername)
    if os.path.exists(log_folder) == False:
        os.mkdir(log_folder)
    logger = logging.getLogger(name)
    log_file = os.path.join(log_folder, filename)
    log_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    log_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)
    logger.propagate = False
    logger.setLevel(logging.DEBUG)
    return logger

