# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

# import scrapy
from scrapy import Item, Field
class searchRecordItem(Item):
        _id=Field()
        types=Field()
        links=Field()

class rankListItem(Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
        novelsize=Field()
        tags=Field()
        cover=Field()
        novelid=Field()
        novelintroshort=Field()
        authorid=Field()
        novelstep=Field()
        authorname=Field()
        novelname=Field()
        sequence=Field()
        rankclass=Field()

class novelItem(Item):
	nutrition_novel=Field()
	ispackage=Field()
	type_id=Field()
	series=Field()
	novelclass=Field()
	novelcover=Field()
	novelscore=Field()
	novip_clicks=Field()
	novelstyle=Field()
	comment_count=Field()
	authorname=Field()
	renewchaptername=Field()
	renewdate=Field()
	isvip=Field()
	novelsize=Field()
	ranking=Field()
	islock=Field()
	novelintroshort=Field()
	novelid=Field()
	protagonist=Field()
	costar=Field()
	novelstep=Field()
	novelname=Field()
	novelbefavoritedcount=Field()
	noveltags=Field()
	renewchapterid=Field()
	authorid=Field()
	other=Field()
	novelintro=Field()
	novelchaptercount=Field()
	chapterlist=Field()
	_id=Field()
	crawltime=Field()

