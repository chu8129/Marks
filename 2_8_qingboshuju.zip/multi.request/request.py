#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:18:13

import urllib2
import urllib
import time
import hashlib
import random
import os
import redis
import sys
from SSDB import SSDB
from logger import init_logger
from get_headers import get_headers


logger = init_logger("request web")

def request(param):
    host,port,db,set_name,headers = param
    red = SSDB(host,port)
    logger.info("thread n start...")
    from gevent import monkey; monkey.patch_all()
    import gevent
    while 1:
        logger.debug("while for loop")
        try:
            urls = red.request("qpop_back",[set_name,100]) 
            logger.debug("urls:%s"%urls)
            if len(urls.data) == 0:
                sys.stdout.write("list:% empty!!"%set_name)
                sys.stdout.flush()
                break
    
            gevent.joinall([gevent.spawn(get_one_page,[url,headers,red,set_name]) for url in urls.data])

        except Exception as e:
            logger.error(str(e), exc_info=True)


def get_one_page(param):
    url,headers,red,set_name = param
    try:
        import gevent
        with gevent.Timeout(3, False) as timeout:
            logger.debug("url:%s"%url)
            req = urllib2.Request(url=url,headers=random.choice(headers))
            res = urllib2.urlopen(req)
            web = res.read()

            info = red.request("hset",["h_"+set_name,url,web])
            logger.debug("save url:%s,info:%s"%(url,str(info)))

        #logger.info("url: %s Done"%(url))
    except Exception as e:
        logger.error(str(e), exc_info=True)
        red.request("qpush_font",[set_name,url])
