#! /bin/sh                                                                                                                                            

export PATH=$PATH:/usr/local/bin

cd /opt/qiuwen/junjiang
today=$(date +%Y%m%d) 
nohup scrapy crawl list 1>log.$today  2>&1 &
