# -*- coding: utf-8 -*-
from scrapy import Spider
from scrapy.selector import Selector
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy import settings
from scrapy.http import Request,FormRequest,HtmlResponse
from scrapy.linkextractors.lxmlhtml import LxmlLinkExtractor
from scrapy.linkextractors import LinkExtractor
from scrapy.conf import settings
import json
import re
import time
import hashlib
from lxml import etree
import os
import urllib
import uuid
import random
from junjiang.items import novelItem,searchRecordItem,rankListItem
class JjwxcListSpider(CrawlSpider):
    name = "list"
    allowed_domains = ["jjwxc.net"]
    start_urls = (
        "http://android.jjwxc.net/bookstore/getTop?channel=700001&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=700002&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=700003&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=700004&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=100006&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=100007&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=100008&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=100009&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=800001&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=800002&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=800003&offset=0&limit=100",
    "http://android.jjwxc.net/bookstore/getTop?channel=800004&offset=0&limit=100",

)
##    rules=(
##    	Rule(
##    		LxmlLinkExtractor(
##	    		allow=(),
##	    		deny=(),
##	    		),
##    		follow=False,
##    		callback='parseRankList',
##    		),
##    	)
    def start_requests(self):
        for line in self.start_urls:
            yield  FormRequest(str(line),callback=self.parseRankList,method='POST',formdata={'versionCode':'33'})
    def parseRankList(self, response):
        data=json.loads(response.body)
        print len(data),response.url
        for number,value in enumerate(data):
            Item_temp=rankListItem()
            Item_temp["novelsize"]=value["novelSize"]
            Item_temp["tags"]=value["tags"]
            Item_temp["cover"]=value["cover"]
            Item_temp["novelid"]=value["novelId"]
            Item_temp["novelintroshort"]=value["novelIntroShort"]
            Item_temp["authorid"]=value["authorId"]
            Item_temp["novelstep"]=value["novelStep"]
            Item_temp["authorname"]=value["authorName"]
            Item_temp["novelname"]=value["novelName"]
            Item_temp["sequence"]=number+1
            Item_temp["rankclass"]=re.findall('channel=(\d*)',response.request.url)[0]
            yield Item_temp
