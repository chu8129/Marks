#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:09:15

import multiprocessing

def get_pool():
    pool = multiprocessing.Pool(multiprocessing.cpu_count())
    return pool

def get_manager():
    manager = multiprocessing.Manager()
    return manager
