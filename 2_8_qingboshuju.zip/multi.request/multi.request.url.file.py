#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 17:47:38

import urllib2
import os
import time
import json
import sys
import traceback
from multi import get_pool
from multi import get_manager
from request import request
from config import infodict_file
from config import redis_host
from config import redis_port
from config import redis_db
from config import redis_db_url_setname
import multiprocessing

def start(headerfile):

    headers = [eval(line) for line in open(headerfile).readlines()]
    pool = get_pool()
    param_list = [(redis_host,redis_port,redis_db,redis_db_url_setname,headers)]*(multiprocessing.cpu_count()*2)

    try:
    	pool.map_async(request,param_list)
        pool.close()
        pool.join()
    except:
        traceback.print_exc()

if __name__ == "__main__":
    start(sys.argv[1])
