#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:11:25
import json


def get_headers(filepath):
    headers = []
    with open(filepath) as fr:
        while 1:
            line = fr.readline()
            if line == "":
                break
            headers.append(json.loads(line))
    return headers
