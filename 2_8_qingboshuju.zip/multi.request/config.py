#!/usr/bin/env python
# -*- coding: utf-8 -*-
# qw @ 2017-08-16 18:37:50

data_path = "./data"
infodict_file = "infodict"

redis_host = "localhost"
redis_port = 9404
redis_db = 0
redis_db_url_setname = "s_url"
