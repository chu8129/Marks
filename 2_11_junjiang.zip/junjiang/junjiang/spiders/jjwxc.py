# -*- coding: utf-8 -*-
from scrapy import Spider
from scrapy.selector import Selector
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy import settings
from scrapy.http import Request,FormRequest,HtmlResponse
from scrapy.linkextractors.lxmlhtml import LxmlLinkExtractor
from scrapy.linkextractors import LinkExtractor
from scrapy.conf import settings
import json
import re
import time
import hashlib
from lxml import etree
import os
import urllib
import uuid
import random
from junjiang.items import novelItem,searchRecordItem
class JjwxcSpider(CrawlSpider):
    name = "jjwxc"
    allowed_domains = ["jjwxc.net"]
    start_urls = (
##        'http://www.jjwxc.net/bookbase.php?fw0=0&fbsj=0&ycx0=0&xx0=0&sd0=0&lx0=0&fg0=0&collectiontypes=ors&null=0&searchkeywords=',
        'http://www.jjwxc.net/bookbase.php?collectiontypes=ors&fbsj=0&fg0=0&fw0=0&isfinish=0&lx0=0&page=%s&sd0=0&searchkeywords=&sortType=0&xx0=0&ycx0=0'%885,
    )
    rules=(
    	Rule(
    		LxmlLinkExtractor(
	    		allow=('bookbase.php'),
##	    		deny=('page=\d{3}','page=\d{2}'),
	    		),
    		follow=True,
    		callback='parseSearchPage',
    		),
    	)
    # def start_requests(self):
    #     for line in self.start_urls:
    #         yield  FormRequest(self.already_url+str(line),callback=self.parse_get_novel,method='POST',formdata={'versionCode':'33'})
    def parseSearchPage(self, response):
	links=LinkExtractor(allow=('onebook.php\?novelid'),deny=()).extract_links(response)
        if links:
        	for line_link in links:
        		novel_id=re.findall('novelid=(\d*)', line_link.url)
        		if novel_id:
        			for line_id in novel_id:
##                                        print 'http://android.jjwxc.net/androidapi/novelbasicinfo?novelId='+line_id
        				yield FormRequest(url='http://android.jjwxc.net/androidapi/novelbasicinfo?novelId='+line_id,callback=self.parseNovelPage,method='POST',formdata={'versionCode':'33'},priority=5)
        elif not(response.request.meta.has_key['trytimes']):
            request=response.request
            request.dont_filter=True
            request.meta['trytimes']=1
            yield request
        elif response.request.meta.has_key['trytimes'] and response.request.meta['trytimes']<10:
            request=response.request
            request.dont_filter=True
            request.meta['trytimes'] +=1
            if request.meta.has_key('proxy') : request.meta.pop('proxy')
            yield request
        Item_temp=searchRecordItem()
	Item_temp['types']=1
	Item_temp['links']=len(links)
	Item_temp['_id']=response.request.url
	yield Item_temp
    def parseNovelPage(self,response):
    	response_json=json.loads(response.body)
    	if int(response_json["islock"])==2 : return 
    	Item_temp=novelItem()
	Item_temp["nutrition_novel"]=response_json["nutrition_novel"] if response_json.has_key("nutrition_novel") else ''
	Item_temp["ispackage"]=response_json["isPackage"] if response_json.has_key("isPackage") else ''
	Item_temp["type_id"]=response_json["type_id"] if response_json.has_key("type_id") else ''
	Item_temp["series"]=response_json["series"] if response_json.has_key("series") else ''
	Item_temp["novelclass"]=response_json["novelClass"] if response_json.has_key("novelClass") else ''
	Item_temp["novelcover"]=response_json["novelCover"] if response_json.has_key("novelCover") else ''
	Item_temp["novelscore"]=response_json["novelScore"] if response_json.has_key("novelScore") else ''
	Item_temp["novip_clicks"]=response_json["novip_clicks"] if response_json.has_key("novip_clicks") else ''
	Item_temp["novelstyle"]=response_json["novelStyle"] if response_json.has_key("novelStyle") else ''
	Item_temp["comment_count"]=response_json["comment_count"] if response_json.has_key("comment_count") else ''
	Item_temp["authorname"]=response_json["authorName"] if response_json.has_key("authorName") else ''
	Item_temp["renewchaptername"]=response_json["renewChapterName"] if response_json.has_key("renewChapterName") else ''
	Item_temp["renewdate"]=response_json["renewDate"] if response_json.has_key("renewDate") else ''
	Item_temp["isvip"]=response_json["isVip"] if response_json.has_key("isVip") else ''
	Item_temp["novelsize"]=response_json["novelSize"] if response_json.has_key("novelSize") else ''
	Item_temp["ranking"]=response_json["ranking"] if response_json.has_key("ranking") else ''
	Item_temp["islock"]=response_json["islock"] if response_json.has_key("islock") else ''
	Item_temp["novelintroshort"]=response_json["novelIntroShort"] if response_json.has_key("novelIntroShort") else ''
	Item_temp["novelid"]=response_json["novelId"] if response_json.has_key("novelId") else ''
	Item_temp["protagonist"]=response_json["protagonist"] if response_json.has_key("protagonist") else ''
	Item_temp["costar"]=response_json["costar"] if response_json.has_key("costar") else ''
	Item_temp["novelstep"]=response_json["novelStep"] if response_json.has_key("novelStep") else ''
	Item_temp["novelname"]=response_json["novelName"] if response_json.has_key("novelName") else ''
	Item_temp["novelbefavoritedcount"]=response_json["novelbefavoritedcount"] if response_json.has_key("novelbefavoritedcount") else ''
	Item_temp["noveltags"]=response_json["novelTags"] if response_json.has_key("novelTags") else ''
	Item_temp["renewchapterid"]=response_json["renewChapterId"] if response_json.has_key("renewChapterId") else ''
	Item_temp["authorid"]=response_json["authorId"] if response_json.has_key("authorId") else ''
	Item_temp["other"]=response_json["other"] if response_json.has_key("other") else ''
	Item_temp["novelintro"]=response_json["novelIntro"] if response_json.has_key("novelIntro") else ''
	Item_temp["novelchaptercount"]=response_json["novelChapterCount"] if response_json.has_key("novelChapterCount") else ''
	Item_temp["chapterlist"]=response_json["chapterList"] if response_json.has_key("chapterList") else ''
	Item_temp["_id"]=response_json["novelId"] if response_json.has_key("novelId") else ''
	Item_temp['crawltime']=str(time.time())

    	yield Request(url='http://android.jjwxc.net/androidapi/chapterList?novelId='+response_json['novelId'],meta={'novelInfo':Item_temp},callback=self.parseChapterList,priority=10)

    def parseChapterList(self,response):
    	Item_temp=response.meta['novelInfo']
    	Item_temp['chapterlist']=json.loads(response.body)
    	yield Item_temp
