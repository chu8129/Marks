# encoding=utf-8
import random
from scrapy.downloadermiddlewares.useragent  import UserAgentMiddleware
import os
import pymongo

class RandomUserAgent(UserAgentMiddleware):
    def __init__(self,user_agent=''):
        if os.path.exists('./junjiang/useragent.data'):
            path='./junjiang/useragent.data'
        else:
            path='./useragent.data'
        with open(path,'r') as fr:
            self.user_agent_list=fr.readlines() 
        self.user_agent = random.choice(self.user_agent_list)
    def process_request(self, request, spider):
        ua=random.choice(self.user_agent_list)
        if ua:
            request.headers.setdefault('User-Agent', ua)

# class CookiesMiddleware(object):
#     """ 换Cookie """
#
#     def process_request(self, request, spider):
#         cookie = random.choice(cookies)
#         # print len(cookies),cookie,request.url
#         request.cookies = cookie
settings_db={
'MONGODB_SERVER':'127.0.0.1',
'MONGODB_PORT':27017,
'MONGODB_DB':'proxy',
'MONGODB_COLLECTION':'allproxy',
}
class RandomProxyMiddleware(object):
    def __init__(self):
        self.proxydb=self.connect_db(settings_db)
    def connect_db(self,mongodb_settings):
        server=mongodb_settings["MONGODB_SERVER"]
        port=int(mongodb_settings["MONGODB_PORT"])
        db=mongodb_settings["MONGODB_DB"]
        collection=mongodb_settings["MONGODB_COLLECTION"]
        mongo_bind=pymongo.MongoClient(server,port)
        db_bind=mongo_bind[db]
        collection_bind=db_bind[collection]
        return collection_bind
    def process_request(self, request, spider):
        random_int=random.randint(1,self.proxydb.count())
        proxy=self.proxydb.find().skip(random_int-1).limit(1)
        if proxy :
            for line in proxy:
                request.meta['proxy']='http://%s'%line['proxy']
                break
